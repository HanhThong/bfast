const { test, expect } = require('@playwright/test');

test('TC-1.1 signs in', async ({ page }) => {
	await test.step('Open the form', async () => {
		await page.goto('data:text/html,<button id="go" onclick="console.log(`clicked`)">Go</button><p id="gone" hidden>x</p>');
	});
	await page.click('#go');
	await expect(page.locator('#go')).toBeVisible();
	await expect(page.locator('#gone')).toBeVisible({ timeout: 500 });
});
